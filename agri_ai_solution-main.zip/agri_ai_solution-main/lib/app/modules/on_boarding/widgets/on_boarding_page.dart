import 'package:agri_ai_solution/app/core/widgets/common/sizer.dart';
import 'package:flutter/material.dart';

class OnBoardingPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final String description;
  final String image1;
  final String image2;

  const OnBoardingPage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.image1,
    required this.image2,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // العنوان (Title)
          Text(
            title,
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          Sizer(),

          // الصورة الأولى (image1)
          Image.asset(
            image1,
            height: 170,
            width: 170,
          ),
          Sizer(),

          // العنوان الفرعي (Subtitle)
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),

          // الوصف (Description)
          Text(
            description,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[700],
            ),
          ),
          Sizer(),

          // الصورة الثانية (image2)
          Expanded(
            child: Image.asset(
              image2,
              height: 150,
              width: 500,
            ),
          ),
        ],
      ),
    );
  }
}