

import 'package:agri_ai_solution/app/modules/auth/login/bindings/login_binding.dart';
import 'package:agri_ai_solution/app/modules/auth/login/views/login_view.dart';
import 'package:agri_ai_solution/app/modules/on_boarding/bindings/on_boarding_binding.dart';
import 'package:agri_ai_solution/app/modules/on_boarding/views/on_boarding_view.dart';
import 'package:get/get.dart';



part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.home;

  static final routes = [
    GetPage(
      name: _Paths.onBoarding,
      page: () => const OnBoardingView(),
      binding: OnBoardingBinding(),
    ),
    GetPage(
      name: _Paths.login,
      page: () => const LoginView(),
      binding: LoginBinding(),
    ),
  ];
}
