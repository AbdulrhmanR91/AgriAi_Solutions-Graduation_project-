
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';


import '../../../../routes/app_pages.dart';

class LoginController extends GetxController {

  @override
  void onInit() {
    super.onInit();
  }

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final RxBool rememberMe = false.obs;


  void changeRememberMe (){
    rememberMe.value = !rememberMe.value;
    print(rememberMe);
  }
}
