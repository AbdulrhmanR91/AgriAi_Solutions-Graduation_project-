class OnBoardingModel {
  final String title;
  final String subtitle;
  final String description;
  final String image1;
  final String image2;

  OnBoardingModel({
    required this.title,
    required this.subtitle,
    required this.description,
    required this.image1,
    required this.image2,
  });
}