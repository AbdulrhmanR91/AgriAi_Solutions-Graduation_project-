
import 'package:agri_ai_solution/app/core/constants/assets.dart';
import 'package:agri_ai_solution/app/core/widgets/common/sizer.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/login_controller.dart';

class LoginView extends GetView<LoginController> {
  const LoginView({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // الشعار في الأعلى
            Image.asset(Assets.logo, // المسار الصحيح للصورة
              height: 250,
              width: 250,
            ),
            Sizer(),
            // نص ترحيبي
            const Text(
              'AGRI AI SOLUTION',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Your complete farming solution',
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            ),
            const SizedBox(height: 40),

            // حقل البريد الإلكتروني
            TextField(
              controller: controller.emailController,
              decoration: InputDecoration(
                hintText: 'Enter your Email or Phone Number',
                labelText: 'Email or Phone Number',
                labelStyle: TextStyle(color: Colors.green),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30), // زوايا دائرية
                ),
                focusedBorder:  OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide(color: Colors.green)
                ),
                prefixIcon: const Icon(Icons.email, color: Colors.green),
              ),
            ),
            const SizedBox(height: 20),

            // حقل كلمة المرور
            TextField(
              controller: controller.passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter your Password',
                labelText: 'Password',
                labelStyle: TextStyle(color: Colors.green),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30), // زوايا دائرية
                ),
                focusedBorder:  OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide(color: Colors.green)
                ),
                prefixIcon: const Icon(Icons.lock, color: Colors.green),
              ),
            ),
            const SizedBox(height: 10),

            // رابط "نسيت كلمة المرور؟"
            Row(
              children: [
                Obx(() => Row(
                  children: [
                    Checkbox(
                      value: controller.rememberMe.value,

                      activeColor: Colors.green,
                      onChanged: (value) {
                        controller.changeRememberMe();
                      },),
                    Text('Remember me',style: TextStyle(color: Colors.grey[600]),),
                  ],
                ),),
                Spacer(),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      // إضافة وظيفة هنا
                    },
                    child: const Text(
                      'Forgot Password?',
                      style: TextStyle(color: Colors.green),
                    ),
                  ),
                ),
              ],
            ),
            Sizer(),
            Container(
              width:double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  if (controller.emailController.text.isNotEmpty &&
                      controller.passwordController.text.isNotEmpty) {
                    print("sign in");
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter both email and password')),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30), // زوايا دائرية
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 40), // زيادة الـ padding
                ),
                child: const Text(
                  'Sign In',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ),
            Sizer(),
            Row(
              children: [
                Text(
                  "Don't have an account?",
                  style: TextStyle(color: Colors.grey[600]),
                ),
                SizedBox(width: 5,),
                TextButton(
                  onPressed: () {
                    // الانتقال إلى شاشة التسجيل كفرد
                  },
                  child: const Text(
                    'Register',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
