
import 'package:agri_ai_solution/app/modules/on_boarding/widgets/dots.dart';
import 'package:agri_ai_solution/app/modules/on_boarding/widgets/on_boarding_page.dart';
import 'package:agri_ai_solution/app/routes/app_pages.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/on_boarding_controller.dart';

class OnBoardingView extends GetView<OnBoardingController> {
  const OnBoardingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: controller.pageController,
              onPageChanged: (index) {
                controller.currentIndex.value = index;
              },
              itemCount: controller.pages.length,
              itemBuilder: (context, index) {
                return OnBoardingPage(
                  title: controller.pages[index].title,
                  subtitle: controller.pages[index].subtitle,
                  description: controller.pages[index].description,
                  image1: controller.pages[index].image1,
                  image2: controller.pages[index].image2,
                );
              },
            ),
          ),
          Obx(() => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              controller.pages.length,
                  (index) => Dots(index,controller.currentIndex.value),
            ),
          ),),
          const SizedBox(height: 20),
          Obx(() => Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 20,),
            child: ElevatedButton(
              onPressed: () {
                if (controller.currentIndex == controller.pages.length - 1) {
                  Get.toNamed(Routes.login);
                } else {
                  controller.pageController.nextPage(
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.easeInOut,
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 20),
              ),
              child: Text(
                controller.currentIndex == controller.pages.length - 1
                    ? "Let's grow smarter, together!"
                    : "Get started",
                style: const TextStyle(fontSize: 20, color: Colors.white),
              ),
            ),
          ),),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
