import 'package:flutter/material.dart';

class Sizer extends StatelessWidget {
  double? width, height;

  Sizer({super.key, this.width, this.height});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width ?? 10,
      height: height ?? 10,
    );
  }
}
