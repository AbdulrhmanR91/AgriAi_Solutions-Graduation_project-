package com.example.agri_ai_solution

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
