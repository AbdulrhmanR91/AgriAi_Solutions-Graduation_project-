
import 'package:agri_ai_solution/app/core/constants/assets.dart';
import 'package:agri_ai_solution/app/models/on_boarding_model/on_boarding_model.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';



class OnBoardingController extends GetxController {

  @override
  void onInit() {
    super.onInit();
  }

  final PageController pageController = PageController();
  final RxInt currentIndex = 0.obs;
  final List<OnBoardingModel> pages = [
    OnBoardingModel(
      title: "Welcome to",
      image1: Assets.logo,
      subtitle: "Empowering Farmers with AI",
      description: "Discover smarter ways to manage your crops with cutting-edge AI tools.",
      image2: Assets.welcome1,
    ),
    OnBoardingModel(
      title: "Welcome to",
      image1: Assets.logo,
      subtitle: "Diagnose Plant Issues Instantly",
      description: "Simply upload a photo, and let AI detect plant diseases to quick solutions.",
      image2:Assets.welcome2,
    ),
    OnBoardingModel(
      title: "Welcome to",
      image1: Assets.logo,
      subtitle: "Expert Help at Your Fingertips",
      description: "Connect with top agricultural engineers for personalized advice and guidance.",
      image2: Assets.welcome3,
    ),
    OnBoardingModel(
      title: "Welcome to",
      image1: Assets.logo,
      subtitle: "All Your Farming Needs in One App",
      description: "From tools to fertilizers, find everything you need to grow and harvest successfully.",
      image2: Assets.welcome4,
    ),
  ];

}
