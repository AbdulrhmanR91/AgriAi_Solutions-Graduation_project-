import 'package:flutter/material.dart';

Widget Dots(int index,int currentIndex) {
  return Container(
    height: 10,
    width: currentIndex == index ? 20 : 10,
    margin: const EdgeInsets.symmetric(horizontal: 5),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      color: currentIndex == index ? Colors.green : Colors.grey,
    ),
  );
}