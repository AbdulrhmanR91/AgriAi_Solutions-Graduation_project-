abstract class Assets {
  static String logo = 'assets/images/logo.png';
  static String welcome1 = 'assets/images/welcome1.png';
  static String welcome2 = 'assets/images/welcome2.png';
  static String welcome3 = 'assets/images/welcome3.png';
  static String welcome4 = 'assets/images/welcome4.png';
}
